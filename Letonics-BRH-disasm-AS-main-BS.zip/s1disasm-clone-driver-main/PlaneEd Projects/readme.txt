These files are for use with PlaneEd. Simply drag and drop a file onto PlaneEd.exe to start it.

You can find PlaneEd at http://info.sonicretro.org/PlaneED
