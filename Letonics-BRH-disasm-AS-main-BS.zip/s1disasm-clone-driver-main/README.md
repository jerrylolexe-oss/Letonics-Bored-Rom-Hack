You can use this source code for your projects. No problem. :)

Port by TheBlad768

The sound driver is ported from SCE:

See: https://github.com/TheBlad768/Sonic-Clean-Engine-S.C.E.-

s1disasm_git
============

The very latest Sonic 1 Disassembly with Sonic 2 Clone Driver v2 (Mega PCM 2.0 version).

See: http://info.sonicretro.org/Disassemblies

DISCLAIMER:
Any and all content presented in this repository is presented for informational and educational purposes only.
Commercial usage is expressly prohibited. Sonic Retro claims no ownership of any code in these repositories.
You assume any and all responsibility for using this content responsibly. Sonic Retro claims no responsibiliy or warranty.

Check out the Sonic Retro source code:

- https://github.com/sonicretro/s1disasm
